//
//  ViewController.swift
//  0927_practice2
//
//  Created by PigFactory on 2018. 9. 27..
//  Copyright © 2018년 PigFactory. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var labelField: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    

    var value = 0
    
    @IBAction func button(_ sender: UIButton) {
        let alert = UIAlertController(title: "Menu", message: "", preferredStyle: .alert)
        
        
        let addingButton = UIAlertAction(title: "Calculate", style: .default) { _ in
//            self.value += 1
//            self.labelField.text = String(self.value)
            self.value += Int((alert.textFields?.first?.text)!)!
            self.labelField.text = "\(self.value)"
        }

        let cancelButton = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)

        let resetButton = UIAlertAction(title: "Reset", style: .destructive) { _ in
            self.value = 0
            self.labelField.text = "-----"
        }

        
        alert.addAction(addingButton)
        alert.addAction(cancelButton)
        alert.addAction(resetButton)
        alert.addTextField(configurationHandler:  nil)
        
        present(alert, animated: true)
        
        
        
    }
    
}

