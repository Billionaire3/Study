//
//  SecondViewController.swift
//  1002_homework
//
//  Created by PigFactory on 2018. 10. 2..
//  Copyright © 2018년 PigFactory. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var imageFrame: UIImageView!
    @IBOutlet weak var countLabel: UILabel!

    var data = 0
    var imageName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        countLabel.text = "\(data)"
        imageFrame.image = UIImage(named: imageName)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

    
}
