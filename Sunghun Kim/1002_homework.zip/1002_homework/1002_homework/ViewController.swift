//
//  ViewController.swift
//  1002_homework
//
//  Created by PigFactory on 2018. 10. 2..
//  Copyright © 2018년 PigFactory. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func unwindToVC(_ sender: UIStoryboardSegue) {
    }

    var dataVC = 0
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        guard let destination = segue.destination as? SecondViewController else { return }
        dataVC += 1
        destination.data = dataVC
        
        if segue.identifier == "catSegue"{
            destination.imageName = "cat"
        } else if segue.identifier == "dogSegue" {
            destination.imageName = "dog"
        } else if segue.identifier == "birdSegue" {
            destination.imageName = "bird"
        }
        
    }

    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        super.shouldPerformSegue(withIdentifier: identifier, sender: sender)
        if identifier == "birdSegue" {
            return dataVC <= 10 ? true : false
        } else {
        return true
        }
    }
    
}

