//
//  ViewController.swift
//  0921_HW
//
//  Created by PigFactory on 2018. 9. 26..
//  Copyright © 2018년 PigFactory. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

//  1st Homework
    
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var addingButton: UIButton!
    
    
    var value: Int = 0
    @IBAction func adding(_ sender: UIButton) {
        value += 1
        textField.text = "\(value)"
    }
    
    
    
    
//  2nd Homework
    
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var `switch`: UISwitch!
    
    @IBAction func toggle(_ sender: UISwitch) {
        
//        label.text = sender.isOn ? "ON" : "OFF"
        
        if sender.isOn == true {
            label.text = "ON"
        } else {
            label.text = "OFF"
        }
        
    }
    
    
//  3rd Homework
    
    @IBOutlet weak var segmentLabel: UILabel!
    @IBOutlet weak var segment: UISegmentedControl!
    
    @IBAction func segmentToggle(_ sender: UISegmentedControl) {
        let index = sender.selectedSegmentIndex
        let title = sender.titleForSegment(at: index)
        segmentLabel.text = title
        
    }
    
    
    
}

